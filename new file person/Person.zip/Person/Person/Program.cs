﻿using System.Security.Cryptography.X509Certificates;

namespace Gym
{
    class Program
    {
        static void Main()
        {
            Service ServiceRun = new Service();

            ServiceRun.Runmenu1();
            
        }
    }
}
